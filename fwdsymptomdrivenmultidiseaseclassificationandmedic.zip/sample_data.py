import datetime
class student:
    mm=0.1
    name="master"
    detection_result='Not Detected'
    text_color="#FFF"
    file_path=''
    file=''
    title="Multi Disease Prediction"
    title1="MULTI DISEASE PREDICTION"
    titlec="MULTI DISEASE PREDICTION"
    # background='#003366'
    background='#ff9900'
    btn_background='#660000'
    backround_color='#ff9900'
    key = 202312
    bpnn=0
    x=datetime.datetime.now()
    data1=10
    data2=33
    d1=1
    d2=2
    a1=(d1*d1+d2)/d2
    a2=(d1*d1*d2)/d2
    acc=100
    r1=[]
    r2=[]


